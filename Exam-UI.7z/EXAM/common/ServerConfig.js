var url = 'localhost:8082';

var LOGIN_URL = 'http://'+url+'/jsonRequest';
var SERVER_URL = 'http://'+url+'/jsonRequest';