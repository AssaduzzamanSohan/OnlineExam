Ext.define('Desktop.view.login.LoginModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.login-login',
    data: {
        name: 'LMS'
    }
});
