Ext.define('nApp.constants.Type', {
	alias: 'appType',
	alternateClassName: 'appType',
	statics: {
		//CONTACT_TYPE_HOME_PHONE: 10000,	
	}
});