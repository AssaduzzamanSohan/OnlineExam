Ext.define('nApp.constants.StatusType', {
	alias: 'appStatusType',
	alternateClassName: 'appStatusType',
	statics: {
		//PEND_NEW: 'PEND_NEW'
	}
});