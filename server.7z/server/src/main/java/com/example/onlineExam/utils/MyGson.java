package com.example.onlineExam.utils;

import com.google.gson.Gson;

public class MyGson {
	public static Gson gson;
	static {
		gson = new Gson();
	}
}
